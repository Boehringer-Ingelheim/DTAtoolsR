# Technical Implementation Plan: Template-Based DTA Export

## Architecture Overview

### Current Flow
```
write_dta(dta, file, format="docx")
    ↓
    .write_dta_docx(dta, include_signatures, signature_list)
    ↓
    officer::read_docx() → build paragraphs, tables → print()
    ↓
    Output DOCX
```

### Proposed Flow (with template support)
```
write_dta(dta, file, format="docx", template=NULL)
    ↓
    if (is.null(template)) {
        ↓
        .write_dta_docx()  ← existing implementation
    } else {
        ↓
        export_with_template(dta, template, file)
    }
    ↓
    Output DOCX
```

---

## Core Function Signature

```r
#' @title Export DTA with User-Provided Template
#' @description
#' Exports a DTA object by replacing template placeholders with actual values.
#' Template should be a DOCX file with placeholders like {DTA_TITLE}, {SUPPLIER_NAME}, etc.
#'
#' @param dta A DTA object
#' @param template Character path to template DOCX file
#' @param output Character path to output DOCX file
#' @param variables List of additional variables (overrides extracted from DTA)
#' @param quiet Logical. Suppress messages. Default: FALSE
#' @param fallback Logical. Fall back to programmatic generation if template fails. Default: TRUE
#'
#' @return Invisibly returns the output file path
#'
#' @examples
#' \dontrun{
#'   dta <- read_dta_from_yaml("my_dta.yaml")
#'   export_with_template(dta, "template.docx", "output.docx")
#' }
#' @export
export_with_template <- function(
  dta,
  template,
  output,
  variables = NULL,
  quiet = FALSE,
  fallback = TRUE
) {
  # Validation
  if (!file.exists(template)) {
    cli::cli_abort("Template file not found: {template}")
  }
  
  # Extract variables from DTA
  dta_vars <- .extract_template_variables(dta)
  
  # Merge with user-provided variables (user overrides DTA)
  all_vars <- c(dta_vars, variables %||% list())
  
  # Process template
  tryCatch(
    {
      result <- .replace_docx_placeholders(template, all_vars, output)
      if (!isTRUE(quiet)) {
        cli::cli_alert_success("Document exported with template to {output}")
      }
      invisible(output)
    },
    error = function(e) {
      if (isTRUE(fallback)) {
        if (!isTRUE(quiet)) {
          cli::cli_alert_warning(
            "Template processing failed: {e$message}. Using default format."
          )
        }
        # Fall back to programmatic generation
        write_dta(dta, output, format = "docx", quiet = quiet)
      } else {
        cli::cli_abort("Template processing failed: {e$message}")
      }
    }
  )
}
```

---

## Helper Function: Extract Template Variables

```r
#' Extract values from DTA for template placeholders
#' @keywords internal
.extract_template_variables <- function(dta) {
  meta <- dta@metadata %||% DTAMetaData()
  
  # Helper: safely format date
  format_date <- function(d) {
    if (is.null(d) || is.na(d)) return("")
    format(d, "%B %d, %Y")
  }
  
  # Helper: extract supplier name
  supplier_name <- function() {
    if (is.null(meta@receiver)) return("")
    meta@receiver@name %||% ""
  }
  
  # Helper: format contacts as comma-separated string
  format_contacts <- function(contact_list) {
    if (is.null(contact_list) || length(contact_list) == 0) return("")
    contact_names <- sapply(contact_list, function(c) c$name %||% "")
    paste(contact_names, collapse = ", ")
  }
  
  # Helper: get dataset names and count
  dataset_names <- function() {
    paste(names(dta@datasets), collapse = ", ")
  }
  
  dataset_count <- function() {
    length(dta@datasets)
  }
  
  # Extract all values
  list(
    # DTA Metadata
    "{DTA_TITLE}" = meta@title %||% "",
    "{DTA_VERSION}" = meta@version %||% "",
    "{DTA_DATE}" = format_date(meta@date),
    "{DTA_DESCRIPTION}" = meta@description %||% "",
    
    # Supplier Information
    "{SUPPLIER_NAME}" = meta@supplier@name %||% "",
    "{SUPPLIER_EMAIL}" = tryCatch(
      meta@supplier@contacts[[1]]$email %||% "",
      error = function(e) ""
    ),
    "{SUPPLIER_PHONE}" = tryCatch(
      meta@supplier@contacts[[1]]$phone %||% "",
      error = function(e) ""
    ),
    "{SUPPLIER_ADDRESS}" = tryCatch(
      meta@supplier@affiliation$address %||% "",
      error = function(e) ""
    ),
    "{SUPPLIER_CONTACTS}" = tryCatch(
      format_contacts(meta@supplier@contacts),
      error = function(e) ""
    ),
    
    # Receiver Information
    "{RECEIVER_NAME}" = meta@receiver@name %||% "",
    "{RECEIVER_EMAIL}" = tryCatch(
      meta@receiver@contacts[[1]]$email %||% "",
      error = function(e) ""
    ),
    "{RECEIVER_PHONE}" = tryCatch(
      meta@receiver@contacts[[1]]$phone %||% "",
      error = function(e) ""
    ),
    "{RECEIVER_ADDRESS}" = tryCatch(
      meta@receiver@affiliation$address %||% "",
      error = function(e) ""
    ),
    "{RECEIVER_CONTACTS}" = tryCatch(
      format_contacts(meta@receiver@contacts),
      error = function(e) ""
    ),
    
    # Transmission Details
    "{TRANSMISSION_DATE}" = tryCatch(
      format_date(meta@transmission$date_first_transfer),
      error = function(e) ""
    ),
    "{TRANSMISSION_SCHEDULE}" = meta@transmission$frequency %||% "",
    "{TEST_UPLOAD}" = if (isTRUE(meta@transmission$test_upload)) "Yes" else "No",
    "{BLINDED_TRANSFER}" = if (isTRUE(meta@transmission$blinded_transfer)) "Yes" else "No",
    
    # Data Content
    "{DATASET_COUNT}" = as.character(dataset_count()),
    "{DATASET_NAMES}" = dataset_names(),
    "{DATASET_TYPES}" = tryCatch(
      paste(sapply(dta@datasets, function(ds) ds@type), collapse = ", "),
      error = function(e) ""
    ),
    "{TOTAL_COLUMNS}" = as.character(
      sum(sapply(dta@datasets, function(ds) {
        if (ds@type == "tabular") {
          length(ds@specs@columns)
        } else {
          0
        }
      }))
    ),
    "{TOTAL_RULES}" = as.character(
      sum(sapply(dta@datasets, function(ds) {
        if (ds@type == "tabular" && !is.null(ds@specs@rules)) {
          length(as.list(ds@specs@rules))
        } else {
          0
        }
      }))
    ),
    
    # Process Information
    "{ERROR_HANDLING}" = meta@error_handling %||% "",
    "{AUTHORIZED_CORRECTIONS}" = tryCatch(
      if (is.list(meta@authorized_for_corrections)) {
        paste(meta@authorized_for_corrections, collapse = ", ")
      } else {
        meta@authorized_for_corrections %||% ""
      },
      error = function(e) ""
    ),
    "{VERSION_HISTORY}" = tryCatch(
      paste(
        sapply(meta@version_history, function(v) {
          paste0(v$version, " (", v$date, ")")
        }),
        collapse = "; "
      ),
      error = function(e) ""
    )
  )
}
```

---

## Helper Function: Replace Placeholders in DOCX

```r
#' Replace placeholders in a DOCX file
#' @keywords internal
.replace_docx_placeholders <- function(template_path, variables, output_path) {
  # Create temp directory
  temp_dir <- tempfile()
  dir.create(temp_dir)
  on.exit(unlink(temp_dir, recursive = TRUE))
  
  # Unzip template
  utils::unzip(template_path, exdir = temp_dir)
  
  # Find all XML files that might contain content
  xml_files <- c(
    "word/document.xml",           # Main content
    "word/header1.xml",            # Header
    "word/footer1.xml"             # Footer
  )
  
  # Process each XML file
  for (xml_file in xml_files) {
    file_path <- file.path(temp_dir, xml_file)
    
    # Skip if file doesn't exist
    if (!file.exists(file_path)) next
    
    # Read content
    content <- readLines(file_path, encoding = "UTF-8")
    content_text <- paste(content, collapse = "\n")
    
    # Replace each placeholder
    for (placeholder in names(variables)) {
      value <- as.character(variables[[placeholder]])
      
      # Sanitize XML special characters
      value <- .escape_xml_text(value)
      
      # Replace using regex with word boundaries
      # This prevents {NAME} from matching {NAME_FIELD}
      pattern <- paste0("(?<!\\{|\\w)", stringi::stri_escape_regex(placeholder), "(?!\\w|\\})")
      
      content_text <- stringi::stri_replace_all_regex(
        content_text,
        pattern,
        value,
        opts_regex = stringi::stri_opts_regex(case_insensitive = FALSE)
      )
    }
    
    # Write back
    writeLines(
      stringi::stri_split_fixed(content_text, "\n")[[1]],
      file_path,
      useBytes = TRUE
    )
  }
  
  # Repackage as DOCX
  cwd <- getwd()
  on.exit(setwd(cwd), add = TRUE)
  
  setwd(temp_dir)
  
  # Create ZIP file
  # Use system zip command if available, fallback to R zip
  zip_result <- tryCatch(
    system(paste("zip", "-r", "-q", output_path, "."), intern = FALSE),
    error = function(e) {
      # Fallback to R-based zipping
      .zip_docx_safe(temp_dir, output_path)
    }
  )
  
  # Verify output exists and is valid
  if (!file.exists(output_path)) {
    cli::cli_abort("Failed to create output DOCX file")
  }
  
  # Try to read the output to verify it's a valid DOCX
  tryCatch(
    officer::read_docx(output_path),
    error = function(e) {
      cli::cli_abort("Output DOCX file is invalid or corrupted: {e$message}")
    }
  )
  
  invisible(output_path)
}
```

---

## Helper Function: Escape XML Text

```r
#' Escape special XML characters
#' @keywords internal
.escape_xml_text <- function(text) {
  if (is.null(text) || length(text) == 0) return("")
  text <- as.character(text)
  
  # Replace special characters
  # Order matters: & must be first to avoid double-escaping
  text <- gsub("&", "&amp;", text, fixed = TRUE)
  text <- gsub("<", "&lt;", text, fixed = TRUE)
  text <- gsub(">", "&gt;", text, fixed = TRUE)
  text <- gsub("\"", "&quot;", text, fixed = TRUE)
  text <- gsub("'", "&apos;", text, fixed = TRUE)
  
  text
}

#' Unescape XML text
#' @keywords internal
.unescape_xml_text <- function(text) {
  if (is.null(text) || length(text) == 0) return("")
  text <- as.character(text)
  
  # Order matters: must reverse the escape order
  text <- gsub("&apos;", "'", text, fixed = TRUE)
  text <- gsub("&quot;", "\"", text, fixed = TRUE)
  text <- gsub("&gt;", ">", text, fixed = TRUE)
  text <- gsub("&lt;", "<", text, fixed = TRUE)
  text <- gsub("&amp;", "&", text, fixed = TRUE)
  
  text
}
```

---

## Helper Function: ZIP/Unzip DOCX Safely

```r
#' Unzip a DOCX file safely
#' @keywords internal
.unzip_docx_safe <- function(docx_path, exdir) {
  # Use utils::unzip with appropriate options
  result <- utils::unzip(docx_path, exdir = exdir)
  
  if (length(result) == 0) {
    cli::cli_abort("Failed to unzip DOCX file: {docx_path}")
  }
  
  invisible(result)
}

#' Zip a DOCX file safely
#' @keywords internal
.zip_docx_safe <- function(source_dir, output_path) {
  # Get all files in the directory
  all_files <- list.files(
    source_dir,
    recursive = TRUE,
    include.dirs = FALSE,
    all.files = TRUE
  )
  
  if (length(all_files) == 0) {
    cli::cli_abort("No files found to zip in {source_dir}")
  }
  
  # Create ZIP using utils::zip
  cwd <- getwd()
  on.exit(setwd(cwd))
  setwd(source_dir)
  
  result <- utils::zip(
    zipfile = output_path,
    files = all_files,
    flags = "-q"
  )
  
  if (result != 0) {
    cli::cli_abort("Failed to create ZIP file: {output_path}")
  }
  
  invisible(output_path)
}
```

---

## Integration with write_dta()

```r
# Modify existing write_dta() signature
write_dta <- function(
  x,
  file,
  format = NULL,
  overwrite = FALSE,
  include_signatures = TRUE,
  signature_list = NULL,
  template = NULL,           # NEW PARAMETER
  template_variables = NULL, # NEW PARAMETER
  quiet = FALSE
) {
  # ... existing validation code ...
  
  # NEW: Check if template is provided
  if (!is.null(template)) {
    if (format %in% c("docx", NULL)) {
      # Use template-based export
      export_with_template(
        x,
        template = template,
        output = file,
        variables = template_variables,
        quiet = quiet
      )
      return(invisible(file))
    } else if (format == "pdf") {
      # Template → DOCX → PDF
      temp_docx <- tempfile(fileext = ".docx")
      export_with_template(
        x,
        template = template,
        output = temp_docx,
        variables = template_variables,
        quiet = TRUE  # Suppress intermediate message
      )
      .convert_docx_to_pdf(temp_docx, file)
      unlink(temp_docx)
      if (!isTRUE(quiet)) {
        cli::cli_alert_success("Document saved to {file}")
      }
      return(invisible(file))
    } else if (format == "md") {
      cli::cli_abort("Markdown format is not supported with templates. Use DOCX or PDF.")
    }
  }
  
  # ... existing programmatic generation code (unchanged) ...
}
```

---

## Test Cases

### Test 1: Basic Placeholder Replacement
```r
test_that("basic placeholder replacement works", {
  # Create a minimal template
  template <- system.file("extdata/template_example.docx", package = "DTAtools")
  
  # Create test DTA
  dta <- create_example_DTA()
  
  # Export
  output <- tempfile(fileext = ".docx")
  export_with_template(dta, template, output)
  
  # Verify output exists and is readable
  expect_true(file.exists(output))
  expect_gt(file.size(output), 1000)
  
  # Verify it can be read as DOCX
  expect_no_error(officer::read_docx(output))
})
```

### Test 2: Special Characters in Variables
```r
test_that("special XML characters are escaped", {
  variables <- list(
    "{TITLE}" = "Title with <special> & \"characters\"",
    "{NAME}" = "Name with apostrophe's"
  )
  
  # Should not throw error during replacement
  expect_no_error({
    export_with_template(
      create_example_DTA(),
      template = "template.docx",
      output = tempfile(fileext = ".docx"),
      variables = variables
    )
  })
})
```

### Test 3: Missing Template File
```r
test_that("missing template file triggers error", {
  dta <- create_example_DTA()
  
  expect_error(
    export_with_template(dta, "nonexistent.docx", "output.docx"),
    "Template file not found"
  )
})
```

### Test 4: Missing Placeholders in Variables
```r
test_that("missing placeholders are silently ignored", {
  dta <- create_example_DTA()
  template <- system.file("extdata/template_example.docx", package = "DTAtools")
  
  # Template has {DTA_TITLE} but we don't provide it (extract from DTA instead)
  # Should not error
  expect_no_error({
    export_with_template(dta, template, tempfile(fileext = ".docx"))
  })
})
```

### Test 5: Multi-line Content
```r
test_that("multi-line content is preserved", {
  variables <- list(
    "{CONTACTS}" = "John Doe\nJane Smith\nBob Jones"
  )
  
  output <- tempfile(fileext = ".docx")
  export_with_template(
    create_example_DTA(),
    "template.docx",
    output,
    variables = variables
  )
  
  # Verify content preserved
  doc <- officer::read_docx(output)
  text <- docx_summary(doc)$text
  expect_true(any(grepl("John Doe", text, fixed = TRUE)))
})
```

### Test 6: PDF Export with Template
```r
test_that("PDF export works with template", {
  dta <- create_example_DTA()
  template <- system.file("extdata/template_example.docx", package = "DTAtools")
  
  output <- tempfile(fileext = ".pdf")
  write_dta(
    dta,
    file = output,
    format = "pdf",
    template = template
  )
  
  expect_true(file.exists(output))
  expect_gt(file.size(output), 10000)  # PDFs are typically larger
})
```

---

## Example Template File

### Structure
```xml
<?xml version="1.0" encoding="UTF-8"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p>
      <w:pPr>
        <w:pStyle w:val="Heading1"/>
      </w:pPr>
      <w:r>
        <w:t>{DTA_TITLE}</w:t>
      </w:r>
    </w:p>
    
    <w:p>
      <w:r>
        <w:t>Version: </w:t>
      </w:r>
      <w:r>
        <w:t>{DTA_VERSION}</w:t>
      </w:r>
    </w:p>
    
    <w:p>
      <w:r>
        <w:t>Date: </w:t>
      </w:r>
      <w:r>
        <w:t>{DTA_DATE}</w:t>
      </w:r>
    </w:p>
    
    <w:p>
      <w:pPr>
        <w:pStyle w:val="Heading2"/>
      </w:pPr>
      <w:r>
        <w:t>Supplier</w:t>
      </w:r>
    </w:p>
    
    <w:p>
      <w:r>
        <w:t>Name: {SUPPLIER_NAME}</w:t>
      </w:r>
    </w:p>
    
    <w:p>
      <w:r>
        <w:t>Email: {SUPPLIER_EMAIL}</w:t>
      </w:r>
    </w:p>
    
    <!-- More sections... -->
  </w:body>
</w:document>
```

---

## Documentation Structure

### File: `man/export_with_template.Rd`
```
\name{export_with_template}
\alias{export_with_template}
\title{Export DTA with User Template}
\description{
  Exports a DTA object by replacing placeholders in a user-provided
  DOCX template with actual DTA metadata values.
}
\usage{
export_with_template(dta, template, output, variables = NULL, 
                    quiet = FALSE, fallback = TRUE)
}
\arguments{
  \item{dta}{A DTA object}
  \item{template}{Path to template DOCX file}
  \item{output}{Output file path}
  \item{variables}{Optional list of variables to override extracted values}
  \item{quiet}{Suppress console messages}
  \item{fallback}{Fall back to programmatic generation on error}
}
\details{
  Template should contain placeholders like {DTA_TITLE}, {SUPPLIER_NAME}, etc.
  See \code{\link{template-variables}} for complete list.
}
\examples{
\dontrun{
  dta <- read_dta_from_yaml("my_dta.yaml")
  export_with_template(dta, "template.docx", "output.docx")
}
}
```

### File: `vignettes/template-based-export.Rmd`
- Creating templates in Word
- List of all variables
- Examples
- Troubleshooting
- Best practices

---

## Backward Compatibility

### No Breaking Changes
- `write_dta()` without template parameter works exactly as before
- Existing code continues to work unchanged
- New parameter is optional with sensible defaults

### Migration Path
```r
# OLD CODE (still works)
write_dta(dta, "output.docx")

# NEW CODE (with template)
write_dta(dta, "output.docx", template = "my_template.docx")

# Both produce valid DOCX files
```

---

## Error Handling Strategy

### Fail Gracefully
```r
export_with_template(dta, template, output)
  # If template fails:
  #   1. Log error details (but don't show to user if quiet=FALSE)
  #   2. If fallback=TRUE: silently fall back to programmatic generation
  #   3. If fallback=FALSE: throw error with details
```

### Common Error Scenarios
| Scenario | Handling |
|----------|----------|
| Template file missing | Error: "Template file not found" |
| Invalid DOCX template | Error: "Failed to unzip template" |
| Corrupted output ZIP | Error: "Output DOCX file is corrupted" |
| Placeholder not replaced | Warning (logged): "Placeholder {VAR} not found in variables" |
| Very long variable value | Truncate with warning or wrap to multiple lines |

---

## Performance Optimization

### Large DTA Handling
```r
# For DTAs with 100+ datasets:
# 1. Lazy-load variables (don't extract unused ones)
# 2. Stream ZIP processing (avoid full unzip if possible)
# 3. Cache extracted variables (reuse across multiple exports)

# Example: Cached extraction
.extract_template_variables_cached <- function(dta) {
  cache_key <- digest::digest(dta)
  
  if (exists(cache_key, envir = .template_cache)) {
    return(get(cache_key, envir = .template_cache))
  }
  
  vars <- .extract_template_variables(dta)
  assign(cache_key, vars, envir = .template_cache)
  vars
}
```

### Expected Performance
- Unzip: 50-100ms
- Variable extraction: 100-500ms
- Replacement: 50-200ms
- Rezip: 100-300ms
- **Total: 300-1100ms** for typical DTAs

---

## Security Considerations

### Input Validation
```r
# Validate template file
if (!file.exists(template)) stop("Template not found")
if (!file.size(template) > 0) stop("Template is empty")
if (!tools::file_ext(template) == "docx") stop("Template must be .docx")

# Validate XML structure
tryCatch(
  utils::unzip(template, list = TRUE),
  error = function(e) stop("Invalid DOCX file")
)
```

### Prevent Code Injection
```r
# XML special characters MUST be escaped
# {TITLE} containing "<script>" → "&lt;script&gt;"
# This prevents malicious DOCX from executing code
```

### Safe File Operations
```r
# Always use temp directories
temp_dir <- tempfile()
on.exit(unlink(temp_dir, recursive = TRUE))

# Never overwrite without permission
if (file.exists(output_path) && !overwrite) {
  stop("File exists and overwrite = FALSE")
}
```

